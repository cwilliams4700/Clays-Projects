const db = require("../db");

function parseJson(value, fallback) {
  try {
    return JSON.parse(value || fallback);
  } catch {
    return JSON.parse(fallback);
  }
}

function getAssignmentMembers(assignmentId) {
  return db
    .prepare(
      `
      SELECT s.id, s.name, s.email, am.role
      FROM assignment_members am
      INNER JOIN students s ON s.id = am.student_id
      WHERE am.assignment_id = ?
      ORDER BY s.name ASC
      `
    )
    .all(assignmentId);
}

function getAssignmentMessages(assignmentId) {
  return db
    .prepare(
      `
      SELECT cm.id, cm.assignment_id AS assignmentId, cm.student_id AS studentId, s.name, cm.message, cm.created_at AS createdAt
      FROM collaboration_messages cm
      INNER JOIN students s ON s.id = cm.student_id
      WHERE cm.assignment_id = ?
      ORDER BY cm.created_at DESC
      LIMIT 10
      `
    )
    .all(assignmentId);
}

function getDashboard(studentId) {
  const student = db
    .prepare("SELECT id, name, email FROM students WHERE id = ?")
    .get(studentId);

  if (!student) {
    return null;
  }

  const assignments = db
    .prepare(
      `
      SELECT
        a.id,
        a.title,
        a.course_name AS courseName,
        a.prompt,
        a.rubric,
        a.due_date AS dueDate,
        a.max_score AS maxScore,
        ap.completion_percent AS completionPercent,
        ap.completed_checklist AS completedChecklist,
        ap.last_updated_at AS lastUpdatedAt,
        s.id AS submissionId,
        s.final_grade AS finalGrade,
        s.numeric_score AS numericScore,
        s.feedback
      FROM assignments a
      INNER JOIN assignment_members am ON am.assignment_id = a.id
      LEFT JOIN assignment_progress ap ON ap.assignment_id = a.id
      LEFT JOIN submissions s ON s.assignment_id = a.id
      WHERE am.student_id = ?
      ORDER BY a.due_date ASC
      `
    )
    .all(studentId)
    .map((assignment) => ({
      ...assignment,
      completedChecklist: parseJson(assignment.completedChecklist, "[]"),
      members: getAssignmentMembers(assignment.id),
      messages: getAssignmentMessages(assignment.id)
    }));

  return { student, assignments };
}

function getAssignmentById(assignmentId) {
  return db.prepare("SELECT * FROM assignments WHERE id = ?").get(assignmentId);
}

function addMessage(assignmentId, studentId, message) {
  const createdAt = new Date().toISOString();

  const result = db
    .prepare(
      `
      INSERT INTO collaboration_messages (assignment_id, student_id, message, created_at)
      VALUES (?, ?, ?, ?)
      `
    )
    .run(assignmentId, studentId, message, createdAt);

  return db
    .prepare(
      `
      SELECT cm.id, cm.assignment_id AS assignmentId, cm.student_id AS studentId, s.name, cm.message, cm.created_at AS createdAt
      FROM collaboration_messages cm
      INNER JOIN students s ON s.id = cm.student_id
      WHERE cm.id = ?
      `
    )
    .get(result.lastInsertRowid);
}

function getAssignmentProgress(assignmentId) {
  const row = db
    .prepare("SELECT * FROM assignment_progress WHERE assignment_id = ?")
    .get(assignmentId);

  if (!row) {
    return {
      assignment_id: assignmentId,
      completion_percent: 0,
      completed_checklist: "[]",
      last_updated_by: null,
      last_updated_at: null
    };
  }

  return row;
}

function upsertProgress(assignmentId, studentId, completionPercent, completedChecklist) {
  const lastUpdatedAt = new Date().toISOString();
  const checklistJson = JSON.stringify(completedChecklist);

  db.prepare(
    `
    INSERT INTO assignment_progress (
      assignment_id,
      completion_percent,
      completed_checklist,
      last_updated_by,
      last_updated_at
    )
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(assignment_id) DO UPDATE SET
      completion_percent = excluded.completion_percent,
      completed_checklist = excluded.completed_checklist,
      last_updated_by = excluded.last_updated_by,
      last_updated_at = excluded.last_updated_at
    `
  ).run(assignmentId, completionPercent, checklistJson, studentId, lastUpdatedAt);

  return getAssignmentProgress(assignmentId);
}

function getAssignmentStats(assignmentId) {
  const progress = getAssignmentProgress(assignmentId);

  const messageCount = db
    .prepare("SELECT COUNT(*) AS count FROM collaboration_messages WHERE assignment_id = ?")
    .get(assignmentId).count;

  const memberCount = db
    .prepare("SELECT COUNT(*) AS count FROM assignment_members WHERE assignment_id = ?")
    .get(assignmentId).count;

  const checklistCount = parseJson(progress.completed_checklist, "[]").length;

  return {
    completionPercent: progress.completion_percent,
    messageCount,
    memberCount,
    checklistCount
  };
}

function createSubmission(assignmentId, submittedBy, gradingResult) {
  const submittedAt = new Date().toISOString();

  db.prepare(
    `
    INSERT INTO submissions (assignment_id, submitted_by, submitted_at, final_grade, numeric_score, feedback)
    VALUES (?, ?, ?, ?, ?, ?)
    `
  ).run(
    assignmentId,
    submittedBy,
    submittedAt,
    gradingResult.finalGrade,
    gradingResult.numericScore,
    gradingResult.feedback
  );

  return getSubmission(assignmentId);
}

function getSubmission(assignmentId) {
  return db
    .prepare("SELECT * FROM submissions WHERE assignment_id = ? ORDER BY submitted_at DESC LIMIT 1")
    .get(assignmentId);
}

module.exports = {
  addMessage,
  createSubmission,
  getAssignmentById,
  getAssignmentMessages,
  getAssignmentProgress,
  getAssignmentStats,
  getDashboard,
  getSubmission,
  upsertProgress
};
