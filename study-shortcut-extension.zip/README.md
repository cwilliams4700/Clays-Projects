# Study Shortcut Extension

Study Shortcut is an AI-powered browser extension and SQL-backed API for collaborative coursework. Students can log in, work in assignment groups, track progress, ask for AI help, and receive a grade when their team submits. Teachers can log in to monitor courses, group progress, and submission outcomes from the same product.

## Product Features

- Real authentication with role-based access for students and teachers
- Multi-course and multi-assignment support backed by SQLite
- Group-based collaboration, messages, and shared progress tracking
- Teacher dashboard showing assignments, group completion, and submissions
- AI study coach with OpenAI Responses API support and mock fallback
- Automatic submission grading based on completion and collaboration signals

## Tech Stack

- Browser extension: Manifest V3, HTML, CSS, vanilla JavaScript
- API: Node.js + Express
- Database: SQLite
- AI provider: OpenAI via the `Responses API`

## Project Structure

- `extension/` browser extension UI
- `server/` API, repositories, and services
- `sql/` schema and seed data
- `data/` SQLite database output

## Quick Start

1. Install Node.js, then install dependencies:

```bash
npm install
```

2. Copy env settings:

```bash
copy .env.example .env
```

3. Initialize the database:

```bash
npm run db:init
```

4. Start the API:

```bash
npm run dev
```

5. Load the extension:

- Open `chrome://extensions`
- Enable Developer Mode
- Click `Load unpacked`
- Select the `extension` folder

## Environment

Default local development works with mock AI:

```env
PORT=3000
DB_PATH=
AI_MODE=mock
AI_MODEL=gpt-5-mini
OPENAI_API_KEY=
```

To use OpenAI for real AI assistance, set:

```env
AI_MODE=openai
OPENAI_API_KEY=your_key_here
AI_MODEL=gpt-5-mini
```

## Demo Accounts

- Student: `ava@example.edu` / `studentpass`
- Teacher: `teacher@example.edu` / `teacherpass`

## API Overview

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/student/dashboard`
- `GET /api/teacher/dashboard`
- `POST /api/assignments/:assignmentId/messages`
- `POST /api/assignments/:assignmentId/progress`
- `POST /api/assignments/:assignmentId/ai-assist`
- `POST /api/assignments/:assignmentId/submit`

## Notes

- Seed data includes one teacher, multiple students, two courses, and multiple assignments.
- New accounts are persisted in SQLite and receive session tokens from the API.
- The AI service falls back to mock mode automatically if `AI_MODE` is not `openai` or no API key is present.
- When `DB_PATH` is blank, the app stores SQLite data in `%LOCALAPPDATA%\\StudyShortcut\\app.db` to avoid OneDrive file-lock issues.
