const OpenAI = require("openai");

function parseChecklist(rawChecklist) {
  try {
    return JSON.parse(rawChecklist || "[]");
  } catch {
    return [];
  }
}

function buildMockResponse(assignment, progress, recentMessages) {
  const checklist = parseChecklist(progress.completedChecklistJson);
  const nextStep =
    checklist.length < 3
      ? "Expand your shared checklist with concrete research and writing milestones."
      : "Focus on turning the checklist items into a polished final response.";

  const recentTopics = recentMessages.map((entry) => entry.message).join(" ");
  const collaborationSignal = recentTopics
    ? `Recent collaboration themes: ${recentTopics.slice(0, 180)}`
    : "No recent collaboration messages yet.";

  return {
    summary: `Your team is ${progress.completionPercent}% complete on "${assignment.title}".`,
    suggestions: [
      "Split the prompt into research, drafting, and review tasks.",
      "Have each student post one evidence-backed update before submission.",
      nextStep
    ],
    collaborationSignal
  };
}

function buildPrompt({ assignment, progress, recentMessages }) {
  return [
    "You are an academic collaboration coach for students working on a shared assignment.",
    "Respond as compact JSON with keys summary, suggestions, collaborationSignal.",
    "summary must be one sentence.",
    "suggestions must be an array of exactly 3 short strings.",
    "collaborationSignal must be one short sentence based on the team's current updates.",
    "",
    `Course: ${assignment.courseTitle} (${assignment.courseCode})`,
    `Assignment: ${assignment.title}`,
    `Prompt: ${assignment.prompt}`,
    `Rubric: ${assignment.rubric}`,
    `Due date: ${assignment.dueDate}`,
    `Completion: ${progress.completionPercent}%`,
    `Checklist: ${parseChecklist(progress.completedChecklistJson).join("; ") || "None yet"}`,
    `Members: ${assignment.members.map((member) => `${member.name} (${member.role})`).join(", ")}`,
    `Recent messages: ${recentMessages.map((entry) => `${entry.name}: ${entry.message}`).join(" | ") || "None"}`
  ].join("\n");
}

function parseAiJson(text) {
  try {
    const parsed = JSON.parse(text);
    if (parsed.summary && Array.isArray(parsed.suggestions) && parsed.collaborationSignal) {
      return {
        summary: parsed.summary,
        suggestions: parsed.suggestions.slice(0, 3),
        collaborationSignal: parsed.collaborationSignal
      };
    }
  } catch {
    return null;
  }

  return null;
}

async function getAiAssist({ assignment, progress, recentMessages }) {
  const useOpenAi = process.env.AI_MODE === "openai" && process.env.OPENAI_API_KEY;
  if (!useOpenAi) {
    return buildMockResponse(assignment, progress, recentMessages);
  }

  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const response = await client.responses.create({
    model: process.env.AI_MODEL || "gpt-5-mini",
    reasoning: { effort: "low" },
    input: buildPrompt({ assignment, progress, recentMessages })
  });

  const parsed = parseAiJson(response.output_text || "");
  if (parsed) {
    return parsed;
  }

  return {
    summary: response.output_text || "AI guidance generated.",
    suggestions: [
      "Break the assignment into smaller milestones.",
      "Ask each teammate to post a concrete evidence update.",
      "Review the rubric before final submission."
    ],
    collaborationSignal: "The AI provider returned plain text, so a safe fallback summary was used."
  };
}

module.exports = { getAiAssist };
