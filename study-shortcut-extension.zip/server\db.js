const fs = require("fs");
const path = require("path");
const { DatabaseSync } = require("node:sqlite");

const defaultDbPath = path.join(
  process.env.LOCALAPPDATA || process.cwd(),
  "StudyShortcut",
  "app.db"
);
const dbPath = process.env.DB_PATH || defaultDbPath;
const resolvedDbPath = path.isAbsolute(dbPath) ? dbPath : path.resolve(process.cwd(), dbPath);

fs.mkdirSync(path.dirname(resolvedDbPath), { recursive: true });

const db = new DatabaseSync(resolvedDbPath);
db.exec("PRAGMA foreign_keys = ON;");

module.exports = {
  db,
  resolvedDbPath
};
