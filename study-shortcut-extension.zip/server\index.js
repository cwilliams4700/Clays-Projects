require("dotenv").config();

const express = require("express");
const cors = require("cors");
const {
  addMessageForStudent,
  createSession,
  createSubmissionForStudent,
  createUser,
  deleteSession,
  getAssignmentStatsForStudent,
  getSessionWithUser,
  getStudentAssignmentContext,
  getStudentDashboard,
  getTeacherDashboard,
  getUserByEmail,
  sanitizeUser,
  upsertProgressForStudent
} = require("./repositories/appRepository");
const { getAiAssist } = require("./services/aiService");
const { gradeAssignment } = require("./services/gradingService");
const { createSessionToken, hashPassword, verifyPassword } = require("./services/authService");

const app = express();
const port = Number(process.env.PORT || 3000);
const sessionDurationMs = 1000 * 60 * 60 * 24 * 7;

app.use(cors());
app.use(express.json());

function getBearerToken(req) {
  const header = req.headers.authorization || "";
  if (!header.startsWith("Bearer ")) {
    return null;
  }

  return header.slice("Bearer ".length);
}

function requireAuth(req, res, next) {
  const sessionId = getBearerToken(req);
  if (!sessionId) {
    return res.status(401).json({ error: "Authentication required." });
  }

  const session = getSessionWithUser(sessionId);
  if (!session) {
    return res.status(401).json({ error: "Session expired or invalid." });
  }

  req.auth = {
    sessionId,
    user: sanitizeUser(session)
  };
  return next();
}

function requireRole(role) {
  return (req, res, next) => {
    if (!req.auth || req.auth.user.role !== role) {
      return res.status(403).json({ error: `${role} access required.` });
    }

    return next();
  };
}

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

app.post("/api/auth/register", (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: "name, email, password, and role are required." });
  }

  if (!["student", "teacher"].includes(role)) {
    return res.status(400).json({ error: "role must be student or teacher." });
  }

  if (getUserByEmail(email)) {
    return res.status(409).json({ error: "An account with this email already exists." });
  }

  const user = createUser({
    name: name.trim(),
    email: email.trim().toLowerCase(),
    passwordHash: hashPassword(password),
    role
  });

  const token = createSessionToken();
  const expiresAt = new Date(Date.now() + sessionDurationMs).toISOString();
  createSession({ sessionId: token, userId: user.id, expiresAt });

  return res.status(201).json({
    token,
    user: sanitizeUser(user)
  });
});

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "email and password are required." });
  }

  const user = getUserByEmail(email.trim().toLowerCase());
  if (!user || !verifyPassword(password, user.password_hash)) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  const token = createSessionToken();
  const expiresAt = new Date(Date.now() + sessionDurationMs).toISOString();
  createSession({ sessionId: token, userId: user.id, expiresAt });

  return res.json({
    token,
    user: sanitizeUser(user)
  });
});

app.post("/api/auth/logout", requireAuth, (req, res) => {
  deleteSession(req.auth.sessionId);
  return res.json({ success: true });
});

app.get("/api/auth/me", requireAuth, (req, res) => {
  return res.json({ user: req.auth.user });
});

app.get("/api/student/dashboard", requireAuth, requireRole("student"), (req, res) => {
  const dashboard = getStudentDashboard(req.auth.user.id);
  return res.json(dashboard);
});

app.get("/api/teacher/dashboard", requireAuth, requireRole("teacher"), (req, res) => {
  const dashboard = getTeacherDashboard(req.auth.user.id);
  return res.json(dashboard);
});

app.post("/api/assignments/:assignmentId/messages", requireAuth, requireRole("student"), (req, res) => {
  const { message } = req.body;
  if (!message) {
    return res.status(400).json({ error: "message is required." });
  }

  const created = addMessageForStudent(req.auth.user.id, req.params.assignmentId, message);
  if (!created) {
    return res.status(404).json({ error: "Assignment group not found for this student." });
  }

  return res.status(201).json(created);
});

app.post("/api/assignments/:assignmentId/progress", requireAuth, requireRole("student"), (req, res) => {
  const { completionPercent, completedChecklist } = req.body;
  if (typeof completionPercent !== "number" || !Array.isArray(completedChecklist)) {
    return res.status(400).json({ error: "completionPercent and completedChecklist are required." });
  }

  const progress = upsertProgressForStudent(
    req.auth.user.id,
    req.params.assignmentId,
    Math.max(0, Math.min(100, completionPercent)),
    completedChecklist
  );

  if (!progress) {
    return res.status(404).json({ error: "Assignment group not found for this student." });
  }

  return res.json(progress);
});

app.post("/api/assignments/:assignmentId/ai-assist", requireAuth, requireRole("student"), async (req, res) => {
  const assignment = getStudentAssignmentContext(req.auth.user.id, req.params.assignmentId);
  if (!assignment) {
    return res.status(404).json({ error: "Assignment not found for this student." });
  }

  const response = await getAiAssist({
    assignment,
    progress: {
      completionPercent: assignment.completionPercent || 0,
      completedChecklistJson: JSON.stringify(assignment.completedChecklist || [])
    },
    recentMessages: assignment.messages || []
  });

  return res.json(response);
});

app.post("/api/assignments/:assignmentId/submit", requireAuth, requireRole("student"), (req, res) => {
  const assignment = getStudentAssignmentContext(req.auth.user.id, req.params.assignmentId);
  if (!assignment) {
    return res.status(404).json({ error: "Assignment not found for this student." });
  }

  const stats = getAssignmentStatsForStudent(req.auth.user.id, req.params.assignmentId);
  if (!stats) {
    return res.status(404).json({ error: "Assignment group not found for this student." });
  }

  const submission = createSubmissionForStudent(
    req.auth.user.id,
    req.params.assignmentId,
    gradeAssignment(stats)
  );

  return res.status(201).json(submission || {});
});

app.listen(port, () => {
  console.log(`Study Shortcut API listening on http://localhost:${port}`);
});
