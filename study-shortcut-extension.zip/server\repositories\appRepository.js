const crypto = require("crypto");
const { db } = require("../db");

function parseJson(value, fallback = "[]") {
  try {
    return JSON.parse(value || fallback);
  } catch {
    return JSON.parse(fallback);
  }
}

function createId(prefix) {
  return `${prefix}-${crypto.randomUUID()}`;
}

function sanitizeUser(user) {
  if (!user) {
    return null;
  }

  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    createdAt: user.created_at || user.createdAt
  };
}

function getUserByEmail(email) {
  return db.prepare("SELECT * FROM users WHERE lower(email) = lower(?)").get(email);
}

function getUserById(userId) {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
}

function createUser({ name, email, passwordHash, role }) {
  const id = createId(role);
  const createdAt = new Date().toISOString();

  db.prepare(
    `
    INSERT INTO users (id, name, email, password_hash, role, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
    `
  ).run(id, name, email, passwordHash, role, createdAt);

  return getUserById(id);
}

function createSession({ sessionId, userId, expiresAt }) {
  const createdAt = new Date().toISOString();

  db.prepare(
    `
    INSERT INTO sessions (id, user_id, created_at, expires_at)
    VALUES (?, ?, ?, ?)
    `
  ).run(sessionId, userId, createdAt, expiresAt);
}

function getSessionWithUser(sessionId) {
  return db
    .prepare(
      `
      SELECT
        s.id AS sessionId,
        s.created_at AS createdAt,
        s.expires_at AS expiresAt,
        u.id,
        u.name,
        u.email,
        u.role,
        u.created_at
      FROM sessions s
      INNER JOIN users u ON u.id = s.user_id
      WHERE s.id = ? AND s.expires_at > ?
      `
    )
    .get(sessionId, new Date().toISOString());
}

function deleteSession(sessionId) {
  db.prepare("DELETE FROM sessions WHERE id = ?").run(sessionId);
}

function getGroupMembers(groupId) {
  return db
    .prepare(
      `
      SELECT u.id, u.name, u.email, agm.role
      FROM assignment_group_members agm
      INNER JOIN users u ON u.id = agm.user_id
      WHERE agm.group_id = ?
      ORDER BY u.name ASC
      `
    )
    .all(groupId);
}

function getGroupMessages(groupId) {
  return db
    .prepare(
      `
      SELECT cm.id, cm.assignment_id AS assignmentId, cm.group_id AS groupId, cm.user_id AS userId, u.name, cm.message, cm.created_at AS createdAt
      FROM collaboration_messages cm
      INNER JOIN users u ON u.id = cm.user_id
      WHERE cm.group_id = ?
      ORDER BY cm.created_at DESC
      LIMIT 12
      `
    )
    .all(groupId);
}

function getGroupProgress(groupId) {
  const progress = db.prepare("SELECT * FROM assignment_progress WHERE group_id = ?").get(groupId);

  if (!progress) {
    return {
      group_id: groupId,
      completion_percent: 0,
      completed_checklist: "[]",
      last_updated_by: null,
      last_updated_at: null
    };
  }

  return progress;
}

function getSubmissionByGroup(assignmentId, groupId) {
  return db
    .prepare(
      `
      SELECT *
      FROM submissions
      WHERE assignment_id = ? AND group_id = ?
      ORDER BY submitted_at DESC
      LIMIT 1
      `
    )
    .get(assignmentId, groupId);
}

function getStudentAssignments(userId) {
  const rows = db
    .prepare(
      `
      SELECT
        a.id,
        a.title,
        a.prompt,
        a.rubric,
        a.due_date AS dueDate,
        a.max_score AS maxScore,
        a.status,
        c.id AS courseId,
        c.title AS courseTitle,
        c.code AS courseCode,
        ag.id AS groupId,
        ag.name AS groupName,
        agm.role AS groupRole,
        ap.completion_percent AS completionPercent,
        ap.completed_checklist AS completedChecklist,
        ap.last_updated_at AS lastUpdatedAt,
        s.final_grade AS finalGrade,
        s.numeric_score AS numericScore,
        s.feedback,
        s.ai_summary AS aiSummary,
        s.submitted_at AS submittedAt
      FROM assignments a
      INNER JOIN courses c ON c.id = a.course_id
      INNER JOIN course_enrollments ce ON ce.course_id = c.id
      LEFT JOIN assignment_groups ag ON ag.assignment_id = a.id
      LEFT JOIN assignment_group_members agm ON agm.group_id = ag.id AND agm.user_id = ?
      LEFT JOIN assignment_progress ap ON ap.group_id = ag.id
      LEFT JOIN submissions s ON s.assignment_id = a.id AND s.group_id = ag.id
      WHERE ce.user_id = ?
        AND ce.enrollment_role = 'student'
        AND (ag.id IS NULL OR agm.user_id = ?)
      ORDER BY a.due_date ASC, a.title ASC
      `
    )
    .all(userId, userId, userId);

  return rows.map((row) => ({
    ...row,
    completionPercent: row.completionPercent || 0,
    completedChecklist: parseJson(row.completedChecklist, "[]"),
    members: row.groupId ? getGroupMembers(row.groupId) : [],
    messages: row.groupId ? getGroupMessages(row.groupId) : []
  }));
}

function getStudentDashboard(userId) {
  const user = sanitizeUser(getUserById(userId));
  if (!user || user.role !== "student") {
    return null;
  }

  const courses = db
    .prepare(
      `
      SELECT c.id, c.title, c.code, c.description
      FROM course_enrollments ce
      INNER JOIN courses c ON c.id = ce.course_id
      WHERE ce.user_id = ? AND ce.enrollment_role = 'student'
      ORDER BY c.code ASC
      `
    )
    .all(userId);

  return {
    user,
    courses,
    assignments: getStudentAssignments(userId)
  };
}

function getStudentAssignmentContext(userId, assignmentId) {
  return getStudentAssignments(userId).find((assignment) => assignment.id === assignmentId) || null;
}

function addMessageForStudent(userId, assignmentId, message) {
  const assignment = getStudentAssignmentContext(userId, assignmentId);
  if (!assignment || !assignment.groupId) {
    return null;
  }

  const createdAt = new Date().toISOString();

  const result = db
    .prepare(
      `
      INSERT INTO collaboration_messages (assignment_id, group_id, user_id, message, created_at)
      VALUES (?, ?, ?, ?, ?)
      `
    )
    .run(assignmentId, assignment.groupId, userId, message, createdAt);

  return db
    .prepare(
      `
      SELECT cm.id, cm.assignment_id AS assignmentId, cm.group_id AS groupId, cm.user_id AS userId, u.name, cm.message, cm.created_at AS createdAt
      FROM collaboration_messages cm
      INNER JOIN users u ON u.id = cm.user_id
      WHERE cm.id = ?
      `
    )
    .get(result.lastInsertRowid);
}

function upsertProgressForStudent(userId, assignmentId, completionPercent, completedChecklist) {
  const assignment = getStudentAssignmentContext(userId, assignmentId);
  if (!assignment || !assignment.groupId) {
    return null;
  }

  const lastUpdatedAt = new Date().toISOString();

  db.prepare(
    `
    INSERT INTO assignment_progress (group_id, completion_percent, completed_checklist, last_updated_by, last_updated_at)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(group_id) DO UPDATE SET
      completion_percent = excluded.completion_percent,
      completed_checklist = excluded.completed_checklist,
      last_updated_by = excluded.last_updated_by,
      last_updated_at = excluded.last_updated_at
    `
  ).run(
    assignment.groupId,
    completionPercent,
    JSON.stringify(completedChecklist),
    userId,
    lastUpdatedAt
  );

  return getGroupProgress(assignment.groupId);
}

function getAssignmentStatsForStudent(userId, assignmentId) {
  const assignment = getStudentAssignmentContext(userId, assignmentId);
  if (!assignment || !assignment.groupId) {
    return null;
  }

  const progress = getGroupProgress(assignment.groupId);
  const messageCount = db
    .prepare("SELECT COUNT(*) AS count FROM collaboration_messages WHERE group_id = ?")
    .get(assignment.groupId).count;

  const memberCount = db
    .prepare("SELECT COUNT(*) AS count FROM assignment_group_members WHERE group_id = ?")
    .get(assignment.groupId).count;

  return {
    completionPercent: progress.completion_percent,
    checklistCount: parseJson(progress.completed_checklist, "[]").length,
    memberCount,
    messageCount
  };
}

function createSubmissionForStudent(userId, assignmentId, gradingResult) {
  const assignment = getStudentAssignmentContext(userId, assignmentId);
  if (!assignment || !assignment.groupId) {
    return null;
  }

  const existing = getSubmissionByGroup(assignmentId, assignment.groupId);
  if (existing) {
    return existing;
  }

  const submittedAt = new Date().toISOString();

  db.prepare(
    `
    INSERT INTO submissions (assignment_id, group_id, submitted_by, submitted_at, final_grade, numeric_score, feedback, ai_summary)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `
  ).run(
    assignmentId,
    assignment.groupId,
    userId,
    submittedAt,
    gradingResult.finalGrade,
    gradingResult.numericScore,
    gradingResult.feedback,
    gradingResult.aiSummary
  );

  return getSubmissionByGroup(assignmentId, assignment.groupId);
}

function getTeacherDashboard(userId) {
  const user = sanitizeUser(getUserById(userId));
  if (!user || user.role !== "teacher") {
    return null;
  }

  const courses = db
    .prepare(
      `
      SELECT id, title, code, description
      FROM courses
      WHERE teacher_id = ?
      ORDER BY code ASC
      `
    )
    .all(userId)
    .map((course) => {
      const assignments = db
        .prepare(
          `
          SELECT id, title, prompt, rubric, due_date AS dueDate, status, max_score AS maxScore
          FROM assignments
          WHERE course_id = ?
          ORDER BY due_date ASC
          `
        )
        .all(course.id)
        .map((assignment) => {
          const groups = db
            .prepare(
              `
              SELECT ag.id, ag.name
              FROM assignment_groups ag
              WHERE ag.assignment_id = ?
              ORDER BY ag.name ASC
              `
            )
            .all(assignment.id)
            .map((group) => {
              const progress = getGroupProgress(group.id);
              const submission = getSubmissionByGroup(assignment.id, group.id);

              return {
                ...group,
                completionPercent: progress.completion_percent,
                completedChecklist: parseJson(progress.completed_checklist, "[]"),
                lastUpdatedAt: progress.last_updated_at,
                members: getGroupMembers(group.id),
                messageCount: db
                  .prepare("SELECT COUNT(*) AS count FROM collaboration_messages WHERE group_id = ?")
                  .get(group.id).count,
                submission: submission
                  ? {
                      submittedAt: submission.submitted_at,
                      finalGrade: submission.final_grade,
                      numericScore: submission.numeric_score,
                      feedback: submission.feedback,
                      aiSummary: submission.ai_summary
                    }
                  : null
              };
            });

          return {
            ...assignment,
            groups,
            submittedGroupCount: groups.filter((group) => group.submission).length
          };
        });

      return {
        ...course,
        assignments
      };
    });

  return { user, courses };
}

module.exports = {
  addMessageForStudent,
  createSession,
  createSubmissionForStudent,
  createUser,
  deleteSession,
  getAssignmentStatsForStudent,
  getSessionWithUser,
  getStudentAssignmentContext,
  getStudentDashboard,
  getTeacherDashboard,
  getUserByEmail,
  getUserById,
  sanitizeUser,
  upsertProgressForStudent
};
