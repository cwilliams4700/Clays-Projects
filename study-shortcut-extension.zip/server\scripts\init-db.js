require("dotenv").config();

const fs = require("fs");
const path = require("path");
const { db, resolvedDbPath } = require("../db");

const schemaPath = path.resolve(process.cwd(), "sql/schema.sql");
const seedPath = path.resolve(process.cwd(), "sql/seed.sql");

const schemaSql = fs.readFileSync(schemaPath, "utf8");
const seedSql = fs.readFileSync(seedPath, "utf8");

db.exec(schemaSql);
db.exec(seedSql);

console.log("Database initialized at", resolvedDbPath);
