const API_BASE_URL = "http://localhost:3000/api";
const TOKEN_KEY = "study-shortcut-token";

const state = {
  assignments: [],
  authMode: "login",
  selectedAssignmentId: null,
  token: localStorage.getItem(TOKEN_KEY),
  user: null
};

const elements = {
  aiCard: document.getElementById("aiCard"),
  aiSignal: document.getElementById("aiSignal"),
  aiSuggestions: document.getElementById("aiSuggestions"),
  aiSummary: document.getElementById("aiSummary"),
  assignmentPrompt: document.getElementById("assignmentPrompt"),
  assignmentSelect: document.getElementById("assignmentSelect"),
  assignmentTitle: document.getElementById("assignmentTitle"),
  authCard: document.getElementById("authCard"),
  authSubmit: document.getElementById("authSubmit"),
  authTitle: document.getElementById("authTitle"),
  checklist: document.getElementById("checklist"),
  completionRange: document.getElementById("completionRange"),
  completionValue: document.getElementById("completionValue"),
  courseName: document.getElementById("courseName"),
  dueDate: document.getElementById("dueDate"),
  emailInput: document.getElementById("emailInput"),
  gradePill: document.getElementById("gradePill"),
  groupName: document.getElementById("groupName"),
  loadAssignment: document.getElementById("assignmentSelect"),
  logoutButton: document.getElementById("logoutButton"),
  memberList: document.getElementById("memberList"),
  messageInput: document.getElementById("messageInput"),
  messagesCard: document.getElementById("messagesCard"),
  messagesList: document.getElementById("messagesList"),
  nameInput: document.getElementById("nameInput"),
  nameLabel: document.getElementById("nameLabel"),
  passwordInput: document.getElementById("passwordInput"),
  postMessage: document.getElementById("postMessage"),
  resultCard: document.getElementById("resultCard"),
  resultFeedback: document.getElementById("resultFeedback"),
  resultGrade: document.getElementById("resultGrade"),
  resultScore: document.getElementById("resultScore"),
  roleEyebrow: document.getElementById("roleEyebrow"),
  roleLabel: document.getElementById("roleLabel"),
  roleSelect: document.getElementById("roleSelect"),
  runAiAssist: document.getElementById("runAiAssist"),
  saveProgress: document.getElementById("saveProgress"),
  shellCard: document.getElementById("shellCard"),
  status: document.getElementById("status"),
  studentCard: document.getElementById("studentCard"),
  submitAssignment: document.getElementById("submitAssignment"),
  teacherCard: document.getElementById("teacherCard"),
  teacherCourses: document.getElementById("teacherCourses"),
  toggleAuthMode: document.getElementById("toggleAuthMode"),
  welcomeMeta: document.getElementById("welcomeMeta"),
  welcomeTitle: document.getElementById("welcomeTitle")
};

function setStatus(message) {
  elements.status.textContent = message;
}

function setAuthMode(mode) {
  state.authMode = mode;
  const isRegister = mode === "register";
  elements.authTitle.textContent = isRegister ? "Create account" : "Sign in";
  elements.authSubmit.textContent = isRegister ? "Create account" : "Continue";
  elements.toggleAuthMode.textContent = isRegister ? "Use existing account" : "Create account";
  elements.nameInput.hidden = !isRegister;
  elements.nameLabel.hidden = !isRegister;
  elements.roleSelect.hidden = !isRegister;
  elements.roleLabel.hidden = !isRegister;
}

function getSelectedAssignment() {
  return state.assignments.find((assignment) => assignment.id === state.selectedAssignmentId) || null;
}

function assignmentChecklistToText(checklist) {
  return (checklist || []).join("\n");
}

function textToChecklist(text) {
  return text
    .split("\n")
    .map((item) => item.trim())
    .filter(Boolean);
}

async function fetchJson(url, options = {}) {
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {})
  };

  if (state.token) {
    headers.Authorization = `Bearer ${state.token}`;
  }

  const response = await fetch(url, {
    ...options,
    headers
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: "Request failed." }));
    throw new Error(error.error || "Request failed.");
  }

  return response.json();
}

function clearView() {
  elements.shellCard.hidden = true;
  elements.studentCard.hidden = true;
  elements.messagesCard.hidden = true;
  elements.aiCard.hidden = true;
  elements.resultCard.hidden = true;
  elements.teacherCard.hidden = true;
}

function renderMembers(members) {
  elements.memberList.innerHTML = "";
  members.forEach((member) => {
    const item = document.createElement("div");
    item.className = "member";
    item.innerHTML = `<strong>${member.name}</strong><span>${member.role}</span>`;
    elements.memberList.appendChild(item);
  });
}

function renderMessages(messages) {
  elements.messagesList.innerHTML = "";
  messages.forEach((entry) => {
    const item = document.createElement("div");
    item.className = "message";
    item.innerHTML = `<strong>${entry.name}</strong><span>${entry.message}</span>`;
    elements.messagesList.appendChild(item);
  });
}

function renderSubmission(assignment) {
  if (!assignment.finalGrade) {
    elements.resultCard.hidden = true;
    elements.gradePill.textContent = "In progress";
    return;
  }

  elements.resultCard.hidden = false;
  elements.gradePill.textContent = assignment.finalGrade;
  elements.resultGrade.textContent = assignment.finalGrade;
  elements.resultScore.textContent = `${assignment.numericScore}/100`;
  elements.resultFeedback.textContent = `${assignment.feedback} ${assignment.aiSummary || ""}`.trim();
}

function renderAssignmentSelect(assignments) {
  elements.assignmentSelect.innerHTML = "";
  assignments.forEach((assignment) => {
    const option = document.createElement("option");
    option.value = assignment.id;
    option.textContent = `${assignment.courseCode} - ${assignment.title}`;
    elements.assignmentSelect.appendChild(option);
  });
}

function renderStudentAssignment(assignment) {
  if (!assignment) {
    elements.studentCard.hidden = true;
    elements.messagesCard.hidden = true;
    return;
  }

  elements.studentCard.hidden = false;
  elements.messagesCard.hidden = false;
  elements.courseName.textContent = `${assignment.courseTitle} (${assignment.courseCode})`;
  elements.assignmentTitle.textContent = assignment.title;
  elements.assignmentPrompt.textContent = assignment.prompt;
  elements.dueDate.textContent = assignment.dueDate;
  elements.groupName.textContent = assignment.groupName || "No group assigned yet";
  elements.completionRange.value = assignment.completionPercent || 0;
  elements.completionValue.textContent = `${assignment.completionPercent || 0}%`;
  elements.checklist.value = assignmentChecklistToText(assignment.completedChecklist);
  renderMembers(assignment.members || []);
  renderMessages(assignment.messages || []);
  renderSubmission(assignment);
}

function renderTeacherDashboard(courses) {
  elements.teacherCourses.innerHTML = "";

  courses.forEach((course) => {
    const courseCard = document.createElement("div");
    courseCard.className = "teacher-course";

    const assignmentsHtml = course.assignments
      .map((assignment) => {
        const groupsHtml = assignment.groups
          .map((group) => {
            const members = group.members.map((member) => member.name).join(", ");
            const submission = group.submission
              ? `<div class="meta">Submitted ${group.submission.submittedAt} | ${group.submission.finalGrade} (${group.submission.numericScore}/100)</div><div class="body-text">${group.submission.feedback}</div>`
              : `<div class="meta">Not submitted yet</div>`;

            return `
              <div class="teacher-group">
                <strong>${group.name}</strong>
                <div class="meta">Completion ${group.completionPercent}% | Messages ${group.messageCount}</div>
                <div class="meta">Members: ${members}</div>
                ${submission}
              </div>
            `;
          })
          .join("");

        return `
          <div class="teacher-assignment">
            <strong>${assignment.title}</strong>
            <div class="meta">Due ${assignment.dueDate} | Submitted groups ${assignment.submittedGroupCount}/${assignment.groups.length}</div>
            ${groupsHtml}
          </div>
        `;
      })
      .join("");

    courseCard.innerHTML = `
      <h4>${course.code} - ${course.title}</h4>
      <p class="body-text">${course.description}</p>
      ${assignmentsHtml}
    `;

    elements.teacherCourses.appendChild(courseCard);
  });
}

function showShell(user) {
  elements.authCard.hidden = true;
  elements.shellCard.hidden = false;
  elements.roleEyebrow.textContent = user.role === "teacher" ? "Teacher Access" : "Student Access";
  elements.welcomeTitle.textContent = user.name;
  elements.welcomeMeta.textContent = `${user.email} | ${user.role}`;
}

function showAuth() {
  clearView();
  elements.authCard.hidden = false;
}

async function handleAuthSubmit() {
  const payload = {
    email: elements.emailInput.value.trim(),
    password: elements.passwordInput.value
  };

  if (state.authMode === "register") {
    payload.name = elements.nameInput.value.trim();
    payload.role = elements.roleSelect.value;
  }

  setStatus(state.authMode === "register" ? "Creating account..." : "Signing in...");

  try {
    const response = await fetchJson(`${API_BASE_URL}/auth/${state.authMode}`, {
      method: "POST",
      body: JSON.stringify(payload)
    });

    state.token = response.token;
    state.user = response.user;
    localStorage.setItem(TOKEN_KEY, state.token);
    await loadRoleDashboard();
  } catch (error) {
    setStatus(error.message);
  }
}

async function loadRoleDashboard() {
  if (!state.token) {
    showAuth();
    return;
  }

  setStatus("Loading workspace...");

  try {
    const me = await fetchJson(`${API_BASE_URL}/auth/me`);
    state.user = me.user;
    showShell(state.user);

    if (state.user.role === "teacher") {
      const dashboard = await fetchJson(`${API_BASE_URL}/teacher/dashboard`);
      clearView();
      showShell(state.user);
      elements.teacherCard.hidden = false;
      renderTeacherDashboard(dashboard.courses || []);
      setStatus("Teacher dashboard ready.");
      return;
    }

    const dashboard = await fetchJson(`${API_BASE_URL}/student/dashboard`);
    state.assignments = dashboard.assignments || [];
    state.selectedAssignmentId = state.assignments[0] ? state.assignments[0].id : null;
    clearView();
    showShell(state.user);
    renderAssignmentSelect(state.assignments);
    renderStudentAssignment(getSelectedAssignment());
    setStatus("Student workspace ready.");
  } catch (error) {
    state.token = null;
    state.user = null;
    localStorage.removeItem(TOKEN_KEY);
    showAuth();
    setStatus(error.message);
  }
}

async function saveProgress() {
  const assignment = getSelectedAssignment();
  if (!assignment) {
    return;
  }

  setStatus("Saving progress...");

  try {
    const completionPercent = Number(elements.completionRange.value);
    const completedChecklist = textToChecklist(elements.checklist.value);

    await fetchJson(`${API_BASE_URL}/assignments/${assignment.id}/progress`, {
      method: "POST",
      body: JSON.stringify({ completionPercent, completedChecklist })
    });

    assignment.completionPercent = completionPercent;
    assignment.completedChecklist = completedChecklist;
    elements.completionValue.textContent = `${completionPercent}%`;
    setStatus("Progress saved.");
  } catch (error) {
    setStatus(error.message);
  }
}

async function requestAiAssist() {
  const assignment = getSelectedAssignment();
  if (!assignment) {
    return;
  }

  setStatus("Generating AI guidance...");

  try {
    const response = await fetchJson(`${API_BASE_URL}/assignments/${assignment.id}/ai-assist`, {
      method: "POST"
    });

    elements.aiCard.hidden = false;
    elements.aiSummary.textContent = response.summary;
    elements.aiSignal.textContent = response.collaborationSignal;
    elements.aiSuggestions.innerHTML = "";

    response.suggestions.forEach((suggestion) => {
      const item = document.createElement("li");
      item.textContent = suggestion;
      elements.aiSuggestions.appendChild(item);
    });

    setStatus("AI guidance ready.");
  } catch (error) {
    setStatus(error.message);
  }
}

async function postMessage() {
  const assignment = getSelectedAssignment();
  if (!assignment) {
    return;
  }

  const message = elements.messageInput.value.trim();
  if (!message) {
    setStatus("Write a team update before posting.");
    return;
  }

  setStatus("Posting team update...");

  try {
    const created = await fetchJson(`${API_BASE_URL}/assignments/${assignment.id}/messages`, {
      method: "POST",
      body: JSON.stringify({ message })
    });

    assignment.messages = [created, ...(assignment.messages || [])];
    renderMessages(assignment.messages);
    elements.messageInput.value = "";
    setStatus("Update posted.");
  } catch (error) {
    setStatus(error.message);
  }
}

async function submitAssignment() {
  const assignment = getSelectedAssignment();
  if (!assignment) {
    return;
  }

  setStatus("Submitting assignment...");

  try {
    const submission = await fetchJson(`${API_BASE_URL}/assignments/${assignment.id}/submit`, {
      method: "POST"
    });

    assignment.finalGrade = submission.final_grade || submission.finalGrade;
    assignment.numericScore = submission.numeric_score || submission.numericScore;
    assignment.feedback = submission.feedback;
    assignment.aiSummary = submission.ai_summary || submission.aiSummary;
    renderSubmission(assignment);
    setStatus("Assignment submitted and graded.");
  } catch (error) {
    setStatus(error.message);
  }
}

async function logout() {
  try {
    if (state.token) {
      await fetchJson(`${API_BASE_URL}/auth/logout`, { method: "POST" });
    }
  } catch {
    // Ignore logout errors and clear local state anyway.
  }

  state.token = null;
  state.user = null;
  state.assignments = [];
  state.selectedAssignmentId = null;
  localStorage.removeItem(TOKEN_KEY);
  showAuth();
  setStatus("Signed out.");
}

elements.authSubmit.addEventListener("click", handleAuthSubmit);
elements.toggleAuthMode.addEventListener("click", () => {
  setAuthMode(state.authMode === "login" ? "register" : "login");
});
elements.assignmentSelect.addEventListener("change", (event) => {
  state.selectedAssignmentId = event.target.value;
  renderStudentAssignment(getSelectedAssignment());
});
elements.saveProgress.addEventListener("click", saveProgress);
elements.runAiAssist.addEventListener("click", requestAiAssist);
elements.postMessage.addEventListener("click", postMessage);
elements.submitAssignment.addEventListener("click", submitAssignment);
elements.logoutButton.addEventListener("click", logout);
elements.completionRange.addEventListener("input", () => {
  elements.completionValue.textContent = `${elements.completionRange.value}%`;
});

setAuthMode("login");
showAuth();
loadRoleDashboard();
