function toLetterGrade(score) {
  if (score >= 90) return "A";
  if (score >= 80) return "B";
  if (score >= 70) return "C";
  if (score >= 60) return "D";
  return "F";
}

function buildFeedback(score, stats) {
  const notes = [];

  notes.push(
    stats.completionPercent >= 100
      ? "Assignment checklist is fully complete."
      : "Some checklist work remains incomplete."
  );

  notes.push(
    stats.messageCount >= 5
      ? "Team collaboration was active across the assignment."
      : "Add more team discussion to strengthen collaboration evidence."
  );

  if (stats.memberCount >= 2) {
    notes.push("Shared participation was detected across the group.");
  }

  if (score >= 90) {
    notes.push("The submission is ready for a strong course grade.");
  } else if (score >= 75) {
    notes.push("The work is solid but would benefit from a little more depth.");
  } else {
    notes.push("More progress and clearer contribution tracking are needed.");
  }

  return notes.join(" ");
}

function gradeAssignment(stats) {
  const rawScore = Math.round(
    stats.completionPercent * 0.6 +
      Math.min(stats.messageCount, 10) * 2 +
      Math.min(stats.checklistCount, 10) * 2 +
      Math.min(stats.memberCount, 5) * 4
  );

  const numericScore = Math.max(0, Math.min(100, rawScore));

  return {
    numericScore,
    finalGrade: toLetterGrade(numericScore),
    feedback: buildFeedback(numericScore, stats),
    aiSummary:
      numericScore >= 90
        ? "The submission demonstrates strong collaboration, steady progress tracking, and a complete response."
        : "The submission is partially complete and would benefit from deeper collaboration evidence and fuller completion."
  };
}

module.exports = { gradeAssignment };
