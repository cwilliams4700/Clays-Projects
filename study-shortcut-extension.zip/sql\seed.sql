INSERT INTO users (id, name, email, password_hash, role, created_at) VALUES
  ('teacher-1', 'Professor Rivera', 'teacher@example.edu', 'demo:teacherpass', 'teacher', '2026-03-31T08:00:00.000Z'),
  ('student-1', 'Ava Johnson', 'ava@example.edu', 'demo:studentpass', 'student', '2026-03-31T08:00:00.000Z'),
  ('student-2', 'Liam Patel', 'liam@example.edu', 'demo:studentpass', 'student', '2026-03-31T08:00:00.000Z'),
  ('student-3', 'Mia Chen', 'mia@example.edu', 'demo:studentpass', 'student', '2026-03-31T08:00:00.000Z'),
  ('student-4', 'Noah Brooks', 'noah@example.edu', 'demo:studentpass', 'student', '2026-03-31T08:00:00.000Z');

INSERT INTO courses (id, title, code, description, teacher_id, created_at) VALUES
  ('course-1', 'Environmental Science 201', 'ENV-201', 'Policy and evidence analysis for global climate topics.', 'teacher-1', '2026-03-31T08:05:00.000Z'),
  ('course-2', 'Technical Writing 110', 'TW-110', 'Collaborative writing and peer review for academic work.', 'teacher-1', '2026-03-31T08:05:00.000Z');

INSERT INTO course_enrollments (course_id, user_id, enrollment_role) VALUES
  ('course-1', 'teacher-1', 'teacher'),
  ('course-1', 'student-1', 'student'),
  ('course-1', 'student-2', 'student'),
  ('course-1', 'student-3', 'student'),
  ('course-2', 'teacher-1', 'teacher'),
  ('course-2', 'student-1', 'student'),
  ('course-2', 'student-4', 'student');

INSERT INTO assignments (id, course_id, title, prompt, rubric, due_date, max_score, status, created_at) VALUES
  (
    'assignment-1',
    'course-1',
    'Climate Change Case Study',
    'Work in groups to analyze one climate policy case study and submit a shared, evidence-based response.',
    'Evidence quality, collaboration quality, argument strength, and clarity of recommendations.',
    '2026-04-10',
    100,
    'open',
    '2026-03-31T08:10:00.000Z'
  ),
  (
    'assignment-2',
    'course-1',
    'Energy Transition Brief',
    'Prepare a short collaborative brief comparing two energy transition strategies.',
    'Research depth, team coordination, writing quality, and feasibility of recommendations.',
    '2026-04-17',
    100,
    'open',
    '2026-03-31T08:10:00.000Z'
  ),
  (
    'assignment-3',
    'course-2',
    'Peer Review Reflection',
    'Draft a reflection on how peer feedback changed your revision plan.',
    'Specificity, reflection quality, and revision planning.',
    '2026-04-14',
    100,
    'open',
    '2026-03-31T08:10:00.000Z'
  );

INSERT INTO assignment_groups (id, assignment_id, name) VALUES
  ('group-1', 'assignment-1', 'Policy Analysts'),
  ('group-2', 'assignment-2', 'Grid Futures'),
  ('group-3', 'assignment-3', 'Revision Partners');

INSERT INTO assignment_group_members (group_id, user_id, role) VALUES
  ('group-1', 'student-1', 'leader'),
  ('group-1', 'student-2', 'researcher'),
  ('group-1', 'student-3', 'editor'),
  ('group-2', 'student-1', 'writer'),
  ('group-2', 'student-2', 'researcher'),
  ('group-3', 'student-1', 'author'),
  ('group-3', 'student-4', 'reviewer');

INSERT INTO assignment_progress (group_id, completion_percent, completed_checklist, last_updated_by, last_updated_at) VALUES
  ('group-1', 55, '["Created team outline","Assigned roles","Collected two policy sources"]', 'student-1', '2026-03-31T09:00:00.000Z'),
  ('group-2', 20, '["Picked comparison topics"]', 'student-2', '2026-03-31T09:10:00.000Z'),
  ('group-3', 80, '["Drafted first reflection","Completed peer review","Started revision memo"]', 'student-4', '2026-03-31T09:20:00.000Z');

INSERT INTO collaboration_messages (assignment_id, group_id, user_id, message, created_at) VALUES
  ('assignment-1', 'group-1', 'student-1', 'I drafted the outline and set up section owners.', '2026-03-31T09:05:00.000Z'),
  ('assignment-1', 'group-1', 'student-2', 'I will collect three policy sources before lunch.', '2026-03-31T09:12:00.000Z'),
  ('assignment-1', 'group-1', 'student-3', 'I can polish the final writing once research is in.', '2026-03-31T09:15:00.000Z'),
  ('assignment-3', 'group-3', 'student-1', 'I added the first reflection draft to our notes.', '2026-03-31T09:22:00.000Z'),
  ('assignment-3', 'group-3', 'student-4', 'I left comments on the revision goals section.', '2026-03-31T09:25:00.000Z');

INSERT INTO submissions (assignment_id, group_id, submitted_by, submitted_at, final_grade, numeric_score, feedback, ai_summary) VALUES
  (
    'assignment-3',
    'group-3',
    'student-1',
    '2026-03-31T09:30:00.000Z',
    'A',
    93,
    'Strong revision reflection with clear evidence of peer feedback and collaborative improvement.',
    'The team produced a strong reflective submission with clear revision ownership and polished writing.'
  );
